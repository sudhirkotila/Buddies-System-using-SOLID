using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum BuddyRequestState
{
    Pending = 0,//Request Recived
    Accepted = 1,//Request Accepted
    Declined = 2,//Request Declined
    Remove = 3//Remove from friend list
}

public class BuddiesManager : MonoBehaviour
{
    //Instance
    public static BuddiesManager instance;
    internal BuddiesActionHandler buddyActionHandler = new BuddiesActionHandler();

    //Temp Vars - For Testing
    [Header("Temp Buddy Vars for Testing")]
    public string tempBuddyName;
    public string tempBuddyImage;
    public string tempBuddyUserId;
    public BuddyRequestState tempBuddyRequestState;
    public List<BuddyData> tempBuddiesList = new List<BuddyData>();
    public List<BuddyData> tempBuddyRequestList = new List<BuddyData>();

    void Awake()
    {
        instance = this;
    }

    // Start is called before the first frame update
    void Start()
    {
    }

    private void OnEnable()
    {
    }

    private void OnDisable()
    {
    }

    //=======================Temp Code Start===================//

    [ContextMenu("AddTempBuddy")]
    private void AddTempBuddy()
    {
        BuddyData bdata = new BuddyData();
        bdata.N = tempBuddyName;
        bdata.I = tempBuddyImage;
        bdata._buddyId = tempBuddyUserId;
        bdata.S = (int)tempBuddyRequestState;
        buddyActionHandler.AddBuddy(bdata, (BuddyRequestState)bdata.S);
    }

    [ContextMenu("RemoveTempBuddy")]
    private void RemoveTempBuddy()
    {
        BuddyData bdata = new BuddyData();
        bdata.N = tempBuddyName;
        bdata.I = tempBuddyImage;
        bdata._buddyId = tempBuddyUserId;
        bdata.S = (int)tempBuddyRequestState;
        buddyActionHandler.RemoveBuddy(bdata, (BuddyRequestState)bdata.S);
    }

    [ContextMenu("GetTempBuddy")]
    private void GetTempBuddy()
    {
        print("Count : " + buddyActionHandler.GetBuddies().Count);
        for (int i = 0; i < buddyActionHandler.GetBuddies().Count; i++)
        {
            print((i + 1) + " - " + buddyActionHandler.GetBuddies()[i].N);
        }
        tempBuddiesList = buddyActionHandler.GetBuddies();
    }

    [ContextMenu("GetTempBuddyRequests")]
    private void GetTempBuddyRequests()
    {
        print("Reqs Count : " + buddyActionHandler.GetBuddyRequests().Count);
        for (int i = 0; i < buddyActionHandler.GetBuddyRequests().Count; i++)
        {
            print((i + 1) + " - " + buddyActionHandler.GetBuddyRequests()[i].N);
        }
        tempBuddyRequestList = buddyActionHandler.GetBuddyRequests();

    }

    //============================ Temp Code End ======================//

    //===== Manage Buddies Actions and List =====//

    internal void AddBuddy(BuddyData bData, BuddyRequestState reqState)
    {
        //Removed From Req list after add successfull
        if (reqState == BuddyRequestState.Accepted)
            RemoveBuddy(bData, BuddyRequestState.Pending);

        //Add to List
        buddyActionHandler.AddBuddy(bData, reqState);
    }

    internal void UpdateBuddyData(BuddyData bData)
    {
        //Update to List
        buddyActionHandler.UpdateBuddyData(bData);
    }

    internal void RemoveBuddy(BuddyData bdata, BuddyRequestState reqState)
    {
        buddyActionHandler.RemoveBuddy(bdata, reqState);
    }

    internal void AppendBuddiesList(List<BuddyData> buddies, BuddyRequestState bsState)
    {
        buddyActionHandler.AppendBuddiesList(buddies, bsState);
    }

    internal void ChangeRequestState(BuddyData bdata, BuddyRequestState requestState)
    {
        buddyActionHandler.ChangeRequestState(bdata, requestState);
    }

    internal List<BuddyData> GetAllBuddies()
    {
        return buddyActionHandler.GetBuddies();
    }

    internal List<BuddyData> GetAllBuddiesData(BuddyRequestState requestState)
    {
        List<BuddyData> tempList = new List<BuddyData>();

        for (int i = 0; i < buddyActionHandler.GetBuddies().Count; i++)
        {
            if (buddyActionHandler.GetBuddies()[i].S == (int)requestState)
            {
                tempList.Add(buddyActionHandler.GetBuddies()[i]);
            }
        }
        return tempList;
    }

    [ContextMenu("ClearBuddyList")]
    internal void ClearBuddiesList()
    {
        buddyActionHandler.ClearBuddiesList();
    }

    // Buddy Requests
    internal List<BuddyData> GetAllBuddyRequests()
    {
        return buddyActionHandler.GetBuddyRequests();
    }

    [ContextMenu("ClearBuddyRequestsList")]
    internal void ClearBuddyRequestList()
    {
        buddyActionHandler.ClearBuddyRequestsList();
    }

    internal void SortBuddiesList()
    {
        buddyActionHandler.SortBuddiesList();
    }

    internal void SetOnlineStatus(List<BuddyData> _buddies)
    {
        buddyActionHandler.SetOnlineStatus(_buddies);
    }

    internal bool IsUserInMyBuddyList(string userId)
    {
        return buddyActionHandler.IsUserInMyBuddyList(userId);
    }

    internal bool IsYourBuddiesListFull()
    {
        if (GetAllBuddies().Count >= 100)
        {
            print("<color=red>Your Friends Lists is Full</color>");
            return true;
        }
        return false;
    }

    internal bool IsUserInMyBuddyRequestList(string userId)
    {
        return buddyActionHandler.IsUserInMyBuddyRequestList(userId);
    }

    //===== Manage Buddies Challenges =====//

    internal void AddBuddyChallenge(BuddyChallengeData buddyChallengeData)
    {
        buddyActionHandler.AddBuddyChallenge(buddyChallengeData);
    }

    internal void RemoveBuddyChallenge(BuddyChallengeData buddyChallengeData)
    {
        buddyActionHandler.RemoveBuddyChallenge(buddyChallengeData);
    }

    internal void AppendBuddyChallengesList(List<BuddyChallengeData> buddyChallengesList)
    {
        buddyActionHandler.AppendBuddyChallengesList(buddyChallengesList);
    }

    internal void ClearBuddyChallengesList()
    {
        buddyActionHandler.ClearBuddyChallengesList();
    }

    internal List<BuddyChallengeData> GetAllBuddyChallenges()
    {
        return buddyActionHandler.GetAllBuddyChallenges();
    }


}
