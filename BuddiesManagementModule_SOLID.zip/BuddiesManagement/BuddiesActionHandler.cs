using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//SOLID :--> L ( Liskov Substitution Principle)
public class BuddiesActionHandler : BuddyActions
{
    //===== Buddies Actions Handling =====//

    public override void AddBuddy(BuddyData buddyData, BuddyRequestState reqState)
    {
        buddiesList.AddBuddy(buddyData, reqState);
    }

    public override void UpdateBuddyData(BuddyData buddyData)
    {
        buddiesList.UpdateBuddyData(buddyData);
    }

    public override void AppendBuddiesList(List<BuddyData> buddies, BuddyRequestState reqState)
    {
        buddiesList.AppendBuddiesList(buddies, reqState);
    }

    public override void RemoveBuddy(BuddyData buddyData, BuddyRequestState reqState)
    {
        buddiesList.RemoveBuddy(buddyData, reqState);
    }

    public override void ChangeRequestState(BuddyData buddyData, BuddyRequestState requestState)
    {
        buddiesList.ChangeRequestState(buddyData, requestState);
    }

    public override void ClearBuddiesList()
    {
        buddiesList.ClearBuddiesList();
    }

    public override void ClearBuddyRequestsList()
    {
        buddiesList.ClearBuddyRequestList();
    }

    public override void SortBuddiesList()
    {
        buddiesList.SortBuddiesList();
    }

    public override void SetOnlineStatus(List<BuddyData> _Buddies)
    {
        buddiesList.SetOnlineStatus(_Buddies);
    }

    public override bool IsUserInMyBuddyList(string userId)
    {
        return buddiesList.IsUserInMyBuddyList(userId);
    }

    public override bool IsUserInMyBuddyRequestList(string userId)
    {
        return buddiesList.IsUserInMyBuddyRequestList(userId);
    }


    //===== Buddies Challenges =====//

    public override void AddBuddyChallenge(BuddyChallengeData buddyChallengeData)
    {
        buddiesList.AddBuddyChallenge(buddyChallengeData);
    }

    public override void RemoveBuddyChallenge(BuddyChallengeData buddyChallengeData)
    {
        buddiesList.RemoveBuddyChallenge(buddyChallengeData);
    }

    public override void AppendBuddyChallengesList(List<BuddyChallengeData> buddiesChallengeList)
    {
        buddiesList.AppendBuddyChallengesList(buddiesChallengeList);
    }

    public override void ClearBuddyChallengesList()
    {
        buddiesList.ClearBuddyChallengesList();
    }
}
