
using System.Collections.Generic;

//SOLID :--> O (Open-Close Principle)
//Open for Extention , Closed for Modification
public abstract class BuddyActions
{
    //Buddies Actions
    protected BuddiesList buddiesList;
    public BuddyActions() { this.buddiesList = new BuddiesList(); }
    public abstract void AddBuddy(BuddyData buddyData, BuddyRequestState reqState);
    public abstract void RemoveBuddy(BuddyData buddyData, BuddyRequestState reqState);
    public abstract void AppendBuddiesList(List<BuddyData> buddies, BuddyRequestState reqState);
    public abstract void ChangeRequestState(BuddyData buddyData, BuddyRequestState requestState);
    public abstract void UpdateBuddyData(BuddyData buddyData);
    public abstract void ClearBuddiesList();
    public abstract void SortBuddiesList();
    public abstract void SetOnlineStatus(List<BuddyData> _buddies);
    public abstract void ClearBuddyRequestsList();
    public List<BuddyData> GetBuddies() { return buddiesList.GetAllBuddies(); }
    public List<BuddyData> GetBuddyRequests() { return buddiesList.GetAllBuddyRequests(); }
    public abstract bool IsUserInMyBuddyList(string userId);
    public abstract bool IsUserInMyBuddyRequestList(string userId);

    //Buddies Challenges Actions
    public abstract void AddBuddyChallenge(BuddyChallengeData buddyChallengeData);
    public abstract void RemoveBuddyChallenge(BuddyChallengeData buddyChallengeData);
    public abstract void AppendBuddyChallengesList(List<BuddyChallengeData> buddiesChallengeList);
    public abstract void ClearBuddyChallengesList();
    public List<BuddyChallengeData> GetAllBuddyChallenges() { return buddiesList.GetAllBuddyChallenges(); }
}
