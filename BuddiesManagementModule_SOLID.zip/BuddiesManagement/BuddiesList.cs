using System.Collections.Generic;
using UnityEngine;
//SOLID :--> S : SRP (Single Responsibility Principle)

[System.Serializable]
public class BuddiesMainList
{
    public List<BuddyData> allBuddies = new List<BuddyData>();
    public List<BuddyData> buddyRequests = new List<BuddyData>();
    public List<BuddyChallengeData> buddyChallenges = new List<BuddyChallengeData>();
}

public class BuddiesList
{
    //Obj
    public BuddiesMainList buddiesListObj;

    //Private Vars
    private bool isSavedDataSet;

    #region  Prefs
    public static string buddiesListStr
    {
        get
        {
            return PlayerPrefs.GetString("buddiesListStr", string.Empty);
        }
        set
        {
            PlayerPrefs.SetString("buddiesListStr", value);
        }
    }
    #endregion

    #region BUDDY_ACTIONS

    //Add Buddies 
    public void AddBuddy(BuddyData buddy, BuddyRequestState reqState)
    {
        //Checking allbuddeis data obj
        BuddiesListObjNullCheck();

        if (reqState == BuddyRequestState.Pending)
        {
            if (!IsUserInMyBuddyRequestList(buddy._buddyId))
                buddiesListObj.buddyRequests.Add(buddy);
        }
        else
        {
            if (!IsUserInMyBuddyList(buddy._buddyId))
                buddiesListObj.allBuddies.Add(buddy);
        }

        //Save To Local
        SaveDataToPrefs();
    }

    public void UpdateBuddyData(BuddyData buddyData)
    {
        //Checking allbuddeis data obj
        BuddiesListObjNullCheck();

        //Update Buddy
        BuddyData _buddyData = buddiesListObj.allBuddies.Find(x => x._buddyId == buddyData._buddyId);
        if (_buddyData != null)
        {
            _buddyData = buddyData;
        }
        else
        {
            buddiesListObj.allBuddies.Add(buddyData);
        }

        //Save To Local
        SaveDataToPrefs();
    }

    //Remove Buddy
    public void RemoveBuddy(BuddyData buddy, BuddyRequestState reqState)
    {
        BuddiesListObjNullCheck();

        if (reqState == BuddyRequestState.Pending || reqState == BuddyRequestState.Declined)
        {
            BuddyData bdata = buddiesListObj.buddyRequests.Find(x => x._buddyId == buddy._buddyId);
            if (bdata != null)
                buddiesListObj.buddyRequests.Remove(bdata);
        }
        else
        {
            BuddyData bdata = buddiesListObj.allBuddies.Find(x => x._buddyId == buddy._buddyId);
            if (bdata != null)
                buddiesListObj.allBuddies.Remove(bdata);
        }

        //Save To Local
        SaveDataToPrefs();
    }

    public void ChangeRequestState(BuddyData buddy, BuddyRequestState requestState)
    {
        //Using Loop
        for (int i = 0; i < buddiesListObj.allBuddies.Count; i++)
        {
            if (buddiesListObj.allBuddies[i]._buddyId == buddy._buddyId)
            {
                buddiesListObj.allBuddies[i].S = (int)requestState;
                break;
            }
        }

        SaveDataToPrefs();
    }

    public void AppendBuddiesList(List<BuddyData> buddies, BuddyRequestState reqState)
    {
        if (reqState == BuddyRequestState.Pending)
        {
            if (buddiesListObj.buddyRequests.Count <= 0)
                buddiesListObj.buddyRequests = buddies;
            else
                buddiesListObj.buddyRequests.AddRange(buddies);
        }
        else
        {
            if (buddiesListObj.allBuddies.Count <= 0)
                buddiesListObj.allBuddies = buddies;
            else
                buddiesListObj.allBuddies.AddRange(buddies);
        }

        //Save To Local
        SaveDataToPrefs();
    }

    //Get All Buddies List
    public List<BuddyData> GetAllBuddies()
    {
        if (!isSavedDataSet)
        {
            isSavedDataSet = true;
            ReadBuddiesList();
        }

        return buddiesListObj.allBuddies;
    }

    //Clear Buddies  List
    internal void ClearBuddiesList()
    {
        BuddiesListObjNullCheck();
        buddiesListObj.allBuddies.Clear();
        SaveDataToPrefs();
    }

    //Get All Buddies Requests List
    public List<BuddyData> GetAllBuddyRequests()
    {
        if (!isSavedDataSet)
        {
            isSavedDataSet = true;
            ReadBuddiesList();
        }

        return buddiesListObj.buddyRequests;
    }

    //Clear Buddies Requests  List
    internal void ClearBuddyRequestList()
    {
        BuddiesListObjNullCheck();
        buddiesListObj.buddyRequests.Clear();
        SaveDataToPrefs();
    }

    //Sort Buddies List based on online status
    public void SortBuddiesList()
    {
        buddiesListObj.allBuddies.Sort((x, y) => y.online.CompareTo(x.online));
    }

    public void SetOnlineStatus(List<BuddyData> _buddies)
    {
        for (int i = 0; i < buddiesListObj.allBuddies.Count; i++)
        {
            buddiesListObj.allBuddies[i].online = false;
            for (int j = 0; j < _buddies.Count; j++)
            {
                if (buddiesListObj.allBuddies[i]._buddyId == _buddies[j]._buddyId)
                {
                    buddiesListObj.allBuddies[i].online = true;
                }
            }
        }
        SortBuddiesList();
    }

    public bool IsUserInMyBuddyList(string userId)
    {
        BuddiesListObjNullCheck();
        Debug.Log("Count : " + buddiesListObj.allBuddies.Count);
        if (buddiesListObj.allBuddies.Count == 0) return false;

        for (int i = 0; i < buddiesListObj.allBuddies.Count; i++)
        {
            Debug.Log("ID : " + buddiesListObj.allBuddies[i]._buddyId);

            if (buddiesListObj.allBuddies[i]._buddyId == userId)
            {
                return true;
            }
        }
        return false;
    }

    public bool IsUserInMyBuddyRequestList(string userId)
    {
        BuddiesListObjNullCheck();
        Debug.Log("Count : " + buddiesListObj.buddyRequests.Count);
        if (buddiesListObj.buddyRequests.Count == 0) return false;

        for (int i = 0; i < buddiesListObj.buddyRequests.Count; i++)
        {
            Debug.Log("ID : " + buddiesListObj.buddyRequests[i]._buddyId);

            if (buddiesListObj.buddyRequests[i]._buddyId == userId)
            {
                return true;
            }
        }
        return false;
    }

    public void AddBuddyChallenge(BuddyChallengeData buddyChallengeData)
    {
        buddiesListObj.buddyChallenges.Add(buddyChallengeData);

        SaveDataToPrefs();
    }

    public void RemoveBuddyChallenge(BuddyChallengeData buddyChallengeData)
    {
        BuddyChallengeData bdata = buddiesListObj.buddyChallenges.Find(x => x._id == buddyChallengeData._id);
        if (bdata != null)
            buddiesListObj.buddyChallenges.Remove(buddyChallengeData);

        SaveDataToPrefs();
    }

    public void AppendBuddyChallengesList(List<BuddyChallengeData> buddiesChallengeList)
    {
        if (buddiesListObj.buddyChallenges.Count <= 0)
            buddiesListObj.buddyChallenges = buddiesChallengeList;
        else
            buddiesListObj.buddyChallenges.AddRange(buddiesChallengeList);

        SaveDataToPrefs();
    }

    //Get All Buddies Challenges List
    public List<BuddyChallengeData> GetAllBuddyChallenges()
    {
        if (!isSavedDataSet)
        {
            isSavedDataSet = true;
            ReadBuddiesList();
        }

        return buddiesListObj.buddyChallenges;
    }

    //Clear Buddies Challenges List
    internal void ClearBuddyChallengesList()
    {
        BuddiesListObjNullCheck();
        buddiesListObj.buddyChallenges.Clear();
        SaveDataToPrefs();
    }
    #endregion

    #region  LOCAL_DATA_SAVED
    //Checking for BuddiesObj is Null or not
    private void BuddiesListObjNullCheck()
    {
        if (buddiesListObj == null)
        {
            buddiesListObj = new BuddiesMainList();
        }
    }

    //Read Buddies List
    private void ReadBuddiesList()
    {
        //Checking allbuddeis data obj
        BuddiesListObjNullCheck();

        if (string.IsNullOrEmpty(buddiesListStr)) return;
        buddiesListObj = JsonUtility.FromJson<BuddiesMainList>(buddiesListStr);
    }

    //Save Data To Prefs
    private void SaveDataToPrefs()
    {
        buddiesListStr = JsonUtility.ToJson(buddiesListObj);
        Debug.Log("<color=yellow>Local Saved Buddies List : </color>" + buddiesListStr);
    }

    #endregion


}
