
//Buddies Data Class
[System.Serializable]
public class BuddyData
{
    public string _buddyId; //userId
    public string N; //Name
    public string I; //Profile Pic
    public bool online; //isOnline
    public int S;//Buddy request state
}

[System.Serializable]
public class BuddyChallengeData
{
    public string _id; // Challenge ID
    public string _tableId; // Table ID
    public string _senderId; // Sender ID
    public string _receiverId; // Receiver ID
    public string PC; // Private Room Code
    public int G; // Game ID
    public int LID; // Lobby ID
    public string N; // Buddy Name
    public string I; // Buddy Profile Pic
    public string TCD; // Challenge Creation DateTime
}